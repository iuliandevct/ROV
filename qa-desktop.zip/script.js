const fleetData = {
  support: {
    title: "Support Vessels",
    summary: "Operational status for assigned support craft.",
    availability: "92%",
    tasks: "7",
    risk: "Low",
    rows: [
      ["MV Constanta", "Ready", "Crew handover complete", "06:40"],
      ["Harbor Assist 02", "Service", "Replace starboard pump seal", "11:20"],
      ["Offshore Link", "Watch", "Weather routing review", "14:10"],
      ["Pilot Tender 4", "Ready", "Fuel and safety checklist", "Ready"],
    ],
  },
  survey: {
    title: "Survey Assets",
    summary: "Hydrographic and inspection assets queued for field work.",
    availability: "86%",
    tasks: "5",
    risk: "Medium",
    rows: [
      ["Survey Cat A1", "Ready", "Upload transect plan", "08:15"],
      ["Echo Mapper", "Watch", "GNSS correction check", "09:45"],
      ["Coastal Scan", "Service", "Sonar bracket inspection", "13:30"],
      ["Data Van 3", "Ready", "Export mission archive", "Ready"],
    ],
  },
  rov: {
    title: "ROV Units",
    summary: "Subsea units, gateways, and telemetry readiness.",
    availability: "88%",
    tasks: "4",
    risk: "Low",
    rows: [
      ["ROV-01", "Ready", "LoRa gateway transmitting", "Online"],
      ["ROV-02", "Watch", "Battery pack balance check", "10:00"],
      ["SparkFun Gateway", "Ready", "868 MHz packet stream active", "Online"],
      ["Telemetry Bench", "Service", "Antenna mount pending", "15:00"],
    ],
  },
};

const table = document.querySelector("#fleet-table");
const title = document.querySelector("#fleet-title");
const summary = document.querySelector("#fleet-summary");
const availability = document.querySelector("#metric-availability");
const tasks = document.querySelector("#metric-tasks");
const risk = document.querySelector("#metric-risk");
const syncState = document.querySelector("#sync-state");
const packetSeq = document.querySelector("#packet-seq");

function statusClass(status) {
  return status.toLowerCase() === "ready"
    ? "ready"
    : status.toLowerCase() === "service"
      ? "service"
      : "watch";
}

function renderFleet(group) {
  const data = fleetData[group];
  title.textContent = data.title;
  summary.textContent = data.summary;
  availability.textContent = data.availability;
  tasks.textContent = data.tasks;
  risk.textContent = data.risk;
  syncState.textContent = "Synced just now";
  table.innerHTML = data.rows
    .map(
      ([asset, status, action, eta]) => `
        <tr>
          <td><strong>${asset}</strong></td>
          <td><span class="status ${statusClass(status)}">${status}</span></td>
          <td>${action}</td>
          <td>${eta}</td>
        </tr>
      `
    )
    .join("");
}

document.querySelectorAll(".fleet-tab").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".fleet-tab").forEach((tab) => tab.classList.remove("active"));
    button.classList.add("active");
    renderFleet(button.dataset.group);
  });
});

document.querySelector("#request-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const type = document.querySelector("#request-type").value;
  const priority = document.querySelector("#request-priority").value;
  document.querySelector("#form-status").textContent = `${priority} ${type} request logged locally.`;
});

let seq = 65;
setInterval(() => {
  seq += 1;
  packetSeq.textContent = `seq=${seq}`;
}, 2200);

renderFleet("support");
